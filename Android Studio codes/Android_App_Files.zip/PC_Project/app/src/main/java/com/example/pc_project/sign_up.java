package com.example.pc_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class sign_up extends AppCompatActivity {
    EditText username;
    EditText password;
    EditText name;
    Button save;
    member mem;
    FirebaseDatabase database;
    DatabaseReference reff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        username = findViewById(R.id.editTextTextPersonName2);
        password = findViewById(R.id.editTextTextPersonName3);
        name = findViewById(R.id.editTextTextPersonName);
        save  = findViewById(R.id.button2);
        mem = new member();
        database = FirebaseDatabase.getInstance();
        reff = database.getReference("user");
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mem.setName(name.getText().toString());
                mem.setUsername(username.getText().toString());
                mem.setPassword(password.getText().toString());

                reff.push().setValue(mem);
                Toast.makeText(sign_up.this,"data saved",Toast.LENGTH_LONG);
                finish();
            }
        });



    }
}