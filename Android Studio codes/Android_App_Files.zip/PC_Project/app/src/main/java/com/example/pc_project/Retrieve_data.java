package com.example.pc_project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;

public class Retrieve_data extends AppCompatActivity {
    ListView name,temp,oxylevel,status,status1;
    FirebaseDatabase database;
    DatabaseReference ref;
    ArrayList<String> list,list1,list2,list3,list4;
    ArrayAdapter<String> adapter,adapter1,adapter2,adapter3,adapter4;
    Patient patient;
    String date;
    TextView t2;
    DatePickerDialog.OnDateSetListener mdatesetlistener;
    Button logout;

    int statuscolor = R.id.textView11;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrieve_data);

        Calendar cal = Calendar.getInstance();
        final int year = cal.get(Calendar.YEAR);
        final int month = cal.get(Calendar.MONTH)+1;
        final int day = cal.get(Calendar.DAY_OF_MONTH);
        date=day+"-"+month+"-"+year;
        Log.d("date1",date);
        t2 = findViewById(R.id.textView8);
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatePickerDialog dialog = new DatePickerDialog(Retrieve_data.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,mdatesetlistener,year,month-1,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        logout = findViewById(R.id.button3);
        patient = new Patient();
        name = findViewById(R.id.name);
        temp = findViewById(R.id.temp);
        oxylevel = findViewById(R.id.oxygen);
        status = findViewById(R.id.status);
        status1 = findViewById(R.id.status1);
        database = FirebaseDatabase.getInstance();
        ref = database.getReference(date);
        list = new ArrayList<>();
        list1 = new ArrayList<>();
        list2 = new ArrayList<>();
        list3 = new ArrayList<>();
        list4 = new ArrayList<>();


        adapter = new ArrayAdapter<>(this,R.layout.user_info,R.id.textView,list);
        adapter1 = new ArrayAdapter<>(this,R.layout.user_info2,R.id.textView9,list1);
        adapter2 = new ArrayAdapter<>(this,R.layout.user_info3,R.id.textView10,list2);
        adapter3 = new ArrayAdapter<>(this,R.layout.user_info4,R.id.textView11,list3);
        adapter4 = new ArrayAdapter<>(this,R.layout.user_info5,R.id.textView12,list4);

        Log.i("MSG3","executed before calling refvalue");
        refernece();

        mdatesetlistener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1 ;
                date = dayOfMonth + "-" + month + "-" + year;
                t2.setText("  " + date);
                ref = database.getReference(date);
                Log.d("date2",date);
                refernece();
            }
        };

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


               public void refernece(){
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        list.clear();list1.clear();list2.clear();list3.clear();list4.clear();
                        for(DataSnapshot ds : dataSnapshot.getChildren()){
                            patient = ds.getValue(Patient.class);

                            list.add("  "+patient.getName());
                            list1.add("  "+patient.getBody_Temperature());
                            list2.add("  "+patient.getOxygen_Level());
                            list3.add("  "+patient.getHealth_Condition());
                            if(patient.getHealth_Condition().equals("CRITICAL")){
                                list4.add("  "+patient.getHealth_Condition());
                            }
                            else{
                                list4.add("");
                            }
                        }
                        name.setAdapter(adapter);
                        temp.setAdapter(adapter1);
                        oxylevel.setAdapter(adapter2);
                        status.setAdapter(adapter3);
                        status1.setAdapter(adapter4);
                    }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}