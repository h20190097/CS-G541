package com.example.pc_project;

public class member {
    private String Name;
    private String Username;
    private String password;

    public member() {
    }

    public member(String name, String username, String password) {
        Name = name;
        Username = username;
        this.password = password;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
