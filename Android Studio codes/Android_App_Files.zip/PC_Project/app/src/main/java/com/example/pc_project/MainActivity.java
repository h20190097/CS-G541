package com.example.pc_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    EditText user;
    EditText password;
    Button login;
    String name1;
    String pass1;

    TextView signup;

    FirebaseDatabase database;
    DatabaseReference reff;
    member mem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signup = findViewById(R.id.textView5);
        user = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        login = findViewById(R.id.button);

        database = FirebaseDatabase.getInstance();
        reff = database.getReference("user");
        mem = new member();
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name1 = user.getText().toString();
                pass1 = password.getText().toString();

                reff.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot ds : dataSnapshot.getChildren()){
                            mem = ds.getValue(member.class);
                            if(name1.equals(mem.getUsername()) && pass1.equals(mem.getPassword())){
                                Intent intent = new Intent(MainActivity.this, Retrieve_data.class);
                                startActivity(intent);
                            }
                            else{
                                Toast toast = Toast.makeText(MainActivity.this,"username or password error",Toast.LENGTH_LONG);
                                toast.show();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, sign_up.class);
                startActivity(intent);
            }
        });

    }
}