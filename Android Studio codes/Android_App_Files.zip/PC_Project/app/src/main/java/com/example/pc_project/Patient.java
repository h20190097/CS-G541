package com.example.pc_project;

public class Patient {
        private String Body_Temperature;
        private String Name;
        private String Health_Condition;
        private  String Oxygen_Level;

    public Patient() {
    }

    public Patient(String body_Temperature, String name, String health_Condition, String oxygen_Level) {
        Body_Temperature = body_Temperature;
        Name = name;
        Health_Condition = health_Condition;
        Oxygen_Level = oxygen_Level;
    }

    public String getBody_Temperature() {
        return Body_Temperature;
    }

    public void setBody_Temperature(String body_Temperature) {
        Body_Temperature = body_Temperature;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getHealth_Condition() {
        return Health_Condition;
    }

    public void setHealth_Condition(String health_Condition) {
        Health_Condition = health_Condition;
    }

    public String getOxygen_Level() {
        return Oxygen_Level;
    }

    public void setOxygen_Level(String oxygen_Level) {
        Oxygen_Level = oxygen_Level;
    }
}
